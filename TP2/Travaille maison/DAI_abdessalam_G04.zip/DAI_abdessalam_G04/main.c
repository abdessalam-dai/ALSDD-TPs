#include <stdio.h>
#include "Liste_chainee.c"

int main() {
    Liste *maListe = initialisation();
    insertion(maListe, 4);
    insertion(maListe, 8);
    insertion(maListe, 15);
    suppression(maListe);
    afficherListe(maListe);

    return 0;
}